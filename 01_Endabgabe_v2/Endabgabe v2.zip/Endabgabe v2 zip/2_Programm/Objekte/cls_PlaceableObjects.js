var endabgabe2;
(function (endabgabe2) {
    class PlaceableObjects {
        constructor() {
            //;
        }
        renderObject() {
            //;
        }
        animateObject() {
            //;
        }
        updateObject() {
            this.animateObject();
            this.renderObject();
        }
    }
    endabgabe2.PlaceableObjects = PlaceableObjects;
})(endabgabe2 || (endabgabe2 = {}));
//# sourceMappingURL=cls_PlaceableObjects.js.map