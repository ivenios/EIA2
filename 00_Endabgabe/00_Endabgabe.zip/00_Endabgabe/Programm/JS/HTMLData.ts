namespace hfuChat {
    export let test: string = "motherfucker";
    
    export let htmlData: {[key: string]: string }
        = {
            "Login": "hello",
            "Register": "there",
            "Login Error": "How",
            "Register Error": "Are",
            "Chat Interface": "you"

        };



}