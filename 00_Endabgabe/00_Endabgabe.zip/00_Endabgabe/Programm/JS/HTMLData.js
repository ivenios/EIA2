var hfuChat;
(function (hfuChat) {
    hfuChat.test = "motherfucker";
    hfuChat.htmlData = {
        "Login": "hello",
        "Register": "there",
        "Login Error": "How",
        "Register Error": "Are",
        "Chat Interface": "you"
    };
})(hfuChat || (hfuChat = {}));
//# sourceMappingURL=HTMLData.js.map